package pl.projektowanie.projekt.database.projections;

public interface MovieInfo {
    Long getId();

    //setter for test
    void setId(Long id);
}
